(function ($) {

  $(document).foundation();

})(jQuery);
